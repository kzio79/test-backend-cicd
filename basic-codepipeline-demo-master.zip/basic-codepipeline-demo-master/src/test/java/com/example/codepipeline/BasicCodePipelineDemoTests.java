package com.example.codepipeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicCodePipelineDemoTests {

	@Test
	void contextLoads() {
	}

}
